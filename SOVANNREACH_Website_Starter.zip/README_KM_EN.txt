SOVANNREACH Battle Royale Website
=================================

This is a responsive static website starter.

Preview:
- Open index.html in a browser.

Publish for free:
1. Create a GitHub account and a new public repository (for example: sovannreach-website).
2. Upload index.html to the repository root.
3. In GitHub, open Settings -> Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select main and /(root), then Save.
6. Wait for GitHub Pages to provide the public website URL.

Before publishing:
- Replace hello@sovannreach.example with your real email.
- Add your official social media links.
- Add real gameplay screenshots and a real download link only when available.

Note: This is a promotional website, not the game itself. Some background photos load from Unsplash and need an internet connection.
